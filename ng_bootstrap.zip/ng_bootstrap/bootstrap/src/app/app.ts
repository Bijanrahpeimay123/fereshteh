import { Component, signal } from '@angular/core';

@Component({
  selector: 'app-root',
  imports: [],
  templateUrl: './app.html',
  styleUrl: './app.css',
})
export class App {
  protected readonly title = signal('bootstrap');
  protected message = 'button not clicked';

  onClick() {
    this.message = 'button clicked!';
    console.log(this.message);
  }

  onHover(isHovering: boolean) {
    this.message = isHovering ? 'button hovered!' : 'button not hovered';
    console.log(this.message);
  }
}
